from arduino.app_utils import *
import time

def loop():
    print("--- Starting Servo Sweep Test ---")
    
    # 1. Sweep Pan (Left to Right) at mid-tilt
    for angle in range(0, 181, 10): # 0 to 180 in steps of 10
        Bridge.call("steer_camera", f"{angle},90")
        time.sleep(0.1)
    
    # 2. Sweep Tilt (Down to Up) at mid-pan
    for angle in range(0, 181, 10):
        Bridge.call("steer_camera", f"90,{angle}")
        time.sleep(0.1)
    
    # 3. Return to Center
    Bridge.call("steer_camera", "90,90")
    
    print("Sweep cycle finished. Waiting 5 seconds...")
    time.sleep(5)

# Run the test loop
App.run(user_loop=loop)