# 😀 ServoDemo

### Description

This simple demo shows the ranging of two servo motors for left / right and up / down movement, tilt and pan functions have been implemented.
We use this later for camera movements.

 - Power supply: 5V external, eg drom the USB Hub used here
 - Pan - Pin D5
 - Tilt - Pin D6 both PWM outputs

As sketch library, add the **Servo** library by Michael Margolis, Arduino.
It allows Arduino boards to control a variety of servo motors.



