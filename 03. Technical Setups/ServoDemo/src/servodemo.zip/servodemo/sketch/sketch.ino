#include <Servo.h>                // Standard Servo library
#include "Arduino_RouterBridge.h"

// --- Existing Display Logic Pins ---
// (Keep your current PIN_CS, PIN_DC, etc.)

// --- Servo Configuration ---
Servo panServo;
Servo tiltServo;
const int PAN_PIN = 6;  // Standard PWM pin on Uno Q
const int TILT_PIN = 5; // Standard PWM pin on Uno Q

// This function will be called from Python
void move_servos(String coords) {
    // Format expected: "90,45"
    int commaIndex = coords.indexOf(',');
    if (commaIndex != -1) {
        int pan = coords.substring(0, commaIndex).toInt();
        int tilt = coords.substring(commaIndex + 1).toInt();
        
        panServo.write(constrain(pan, 0, 180));
        tiltServo.write(constrain(tilt, 0, 180));
    }
}

// Add to your existing sketch
void move_servos_test(String coords) {
    int commaIndex = coords.indexOf(',');
    if (commaIndex != -1) {
        int pan = coords.substring(0, commaIndex).toInt();
        int tilt = coords.substring(commaIndex + 1).toInt();
        
        // Safety constraints for standard servos
        pan = constrain(pan, 0, 180);
        tilt = constrain(tilt, 0, 180);
        
        panServo.write(pan);
        tiltServo.write(tilt);
    }
}

void setup() {
    // ... your existing display setup logic ...
    
    // Servo Setup
    panServo.attach(PAN_PIN);
    tiltServo.attach(TILT_PIN);
    panServo.write(90); // Center
    tiltServo.write(90);

    // Bridge Setup
    Bridge.begin();
    Bridge.provide("steer_camera", move_servos_test);      // New servo bridge
}

void loop() {
    // Keep empty as Bridge handles interrupts
}
