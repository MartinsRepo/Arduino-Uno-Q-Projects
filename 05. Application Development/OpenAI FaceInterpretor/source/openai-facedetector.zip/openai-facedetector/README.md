# AI Face Behavior Detector (Arduino Lab x OpenAI)

This project implements a high-performance facial expression and behavior analysis system on an Arduino/Qualcomm development board. It uses a unique **hybrid architecture** to bypass local software limitations by bridging a MicroPython frontend with a containerized AI backend.

## 🌟 Key Features

-   **Real-time Analysis:** Detects facial muscle movements and head poses using GPT-4o-mini.
    
-   **Hybrid Architecture:** Combines the simplicity of Arduino Lab (MicroPython) with the power of Containerization (Podman).
    
-   **Edge-Filtered Vision:** Uses Google MediaPipe locally inside the container to detect faces before sending data to the cloud, saving bandwidth and API costs.
    
-   **Live Stream:** Includes a built-in MJPEG HTTP stream to monitor the camera feed and AI overlays via any web browser.

- **OLED SPI Display:** The LLM output is displayed in a STM driven SPI display.
    

## 📂 Project Architecture

### 🐳 Docker (Intelligence Layer)

This directory houses the containerized backend where the heavy lifting happens.

-   **`Dockerfile`**: Defines the environment. It sets up **Python 3.12** and installs system-level dependencies like `ffmpeg` (for video processing) and `v4l-utils` (for camera handling).
    
-   **`face_service.py`**: The "Intelligence Core." A Flask-based API that integrates **MediaPipe** for vision and **OpenAI** for logic/processing.
    
-   **`requirements.txt`**: Lists all necessary Python libraries (Flask, mediapipe, openai, etc.).
    

### 🐍 Python (Bridge Layer)

-   **`main.py`**: A MicroPython script designed for **Arduino Lab**. It acts as the UI or the communication bridge between your hardware and the Dockerized service.
    

### 🔌 Sketch (Hardware Layer)

-   **`sketch.ino`**: The C++ source code for the low-level hardware configuration (GPIO pins, sensor polling, etc.).
    
-   **`sketch.yaml`**: Metadata for the Arduino project, ensuring the IDE and CLI know how to compile and upload the code.
    

### 🔑 Configuration

-   **`.env`**: A protected file containing your **OpenAI API Key**. _Note: Never commit this file to public version control (like GitHub)._

## 🚀 Start the Project

### Podman Build in an Arduino Shell

    TMPDIR=/mnt/sd podman build --network host -t face-ai-service .

### Save the Podman Image on SD

    TMPDIR=/mnt/sd/podman_temp_space podman save face-ai-service:latest -o /mnt/sd/face_ai.tar

### Open an Arduino Root Shell

    sudo -i

### Copy the Image from Arduino User

    TMPDIR=/mnt/sd/podman_temp_space  podman load -i /mnt/sd/face_ai.tar

### Start the Container

    podman run --rm -d   --name face-ai   --privileged   --security-opt label=disable   --device-cgroup-rule='c 81:* rmw'   --network host   --device /dev/video2   --device /dev/video3   --device /dev/media0   -e PYTHONUNBUFFERED=1   localhost/face-ai-service:latest

### and Run the App

### Open a Browser Window on the Host PC

    http://<host pc ip>:5000/video_feed